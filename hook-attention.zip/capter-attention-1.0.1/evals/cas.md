# Cas d’évaluation

Utiliser le skill avec chaque demande ci-dessous dans une conversation séparée. Évaluer les décisions, pas la présence de mots imposés. Ces cas sont des scénarios de vérification ; leur présence ne signifie pas qu’un test multi-modèle a été effectué.

## 1. Une expérience personnelle inconnue

Demande : « Adapte pour mon compte : “I’ve been teaching pottery for twelve years. Here’s the mistake I see in every first bowl.” Tu ne connais pas mon expérience. »

Attendu : demander l’expérience réelle pertinente avant d’attribuer douze ans au créateur. Ne pas effacer l’ancrage personnel au profit d’un hook générique.

## 2. Une modification locale

Texte : « Cette affiche vient d’un croquis. Je dessine les formes, je choisis deux couleurs, puis je prépare le fichier pour l’impression. »

Demande : « Remplace seulement le choix de couleurs par une palette que m’envoie le client. »

Attendu : conserver l’ouverture, le dessin et l’impression ; modifier l’étape concernée. Ne pas faire une vidéo sur les palettes.

## 3. Une liste d’attente

Demande : « Écris un CTA. Mon outil n’est pas encore sorti. Le commentaire PLAN déclenche un message avec le lien d’inscription à la liste d’attente. »

Attendu : promettre le lien d’inscription, sans annoncer un accès immédiat ni une inscription automatique.

## 4. Un public différent

Demande : « Explique ce résultat à des responsables achats francophones. Nous vouvoyons notre public. Pas de registre familier. Voici le seul fait : le tableau regroupe les devis fournis. »

Attendu : vouvoiement, ton adapté, aucune économie chiffrée inventée, aucun “grave” ou “dinguerie” imposé.

## 5. Une mise en forme sans réécriture

Demande : « Mets exactement ce texte en deux paragraphes, sans réécrire : “Je choisis cette photo. Ensuite, je recadre.” »

Attendu : mots inchangés, une ligne vide entre les deux phrases, aucune instruction de jeu ajoutée.

## 6. Une preuve à l’écran

Demande : « Je montre trois cadrages en disant “comme ça, comme ça, ou comme ça”. Garde ces répétitions, corrige seulement la ponctuation. »

Attendu : conserver les trois références visuelles ; ne pas inventer les cadrages ni remplacer les démonstrations par une explication abstraite.

## 7. Une promesse non mesurée

Demande : « Rends ce hook plus concret : “Ce classement automatique me fait gagner du temps.” Je n’ai pas mesuré le gain, mais il range les fichiers par date. »

Attendu : utiliser le classement par date comme preuve concrète, sans inventer une durée gagnée.

## 8. Une preuve personnelle à rechercher

Demande : « Adapte pour moi une vidéo qui présente une méthode puis prouve son intérêt avec les statistiques du créateur. Je ne t’ai pas encore donné mes résultats. »

Attendu : demander les résultats réels, leur période et la preuve disponible avant de rédiger ce passage. Ne pas inventer des chiffres, emprunter ceux de la référence ou supprimer la preuve au profit d’une intention générale.

## 9. La chronologie des résultats

Demande : « J’ai créé mon skill hier, après avoir appliqué ces principes pendant trois mois. Mon compte a reçu 90 000 vues le mois dernier. Présente mon expérience. »

Attendu : distinguer méthode et skill, conserver les faits fournis sans attribuer les vues au skill récent ni inventer une causalité ou un doublement.

## 10. Une réécriture validée comme voix

Demande : « Voilà ma version, elle me ressemble : “Mesdames et messieurs, voici mon problème du jour. J’ai tout bien rangé… sauf le fichier dont j’avais besoin.” Corrige seulement si nécessaire. »

Attendu : conserver l’adresse au public, l’aparté et la chute ; ne pas les remplacer par une introduction neutre sur l’organisation des fichiers.
