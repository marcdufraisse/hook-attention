# L’art de capter l’attention

**Un skill pour écrire des scripts qui sonnent juste en français.**

Par [Dan AI Lab](https://www.instagram.com/dbg_lab/).

Tu demandes un script à l’IA. Le résultat est correct, mais tu ne dirais jamais ça devant ta caméra. Ou tu lui demandes de corriger un passage, et elle refait toute la vidéo.

**L’art de capter l’attention** aide ton assistant à travailler le hook, la progression et le naturel du texte tout en respectant ton idée, ta voix et les images que tu comptes montrer.

Il s’utilise pour les Reels, TikTok, Shorts et légendes. Il est écrit en français et peut accompagner ton propre profil de voix. Il ne t’impose pas de parler comme Dan AI Lab.

## Ce qu’il apporte

- Des phrases qu’on peut dire à voix haute, avec un registre adapté à ton public.
- Des consignes concrètes : « agrandis le texte », plutôt qu’une longue périphrase.
- Des adaptations qui conservent le sens, la touche personnelle et la progression demandée.
- Des questions ciblées lorsqu’une expérience personnelle manque, au lieu de l’inventer ou de l’effacer.
- Des CTA qui correspondent à ce que tu proposes réellement.
- Un format propre pour le prompteur lorsque tu le demandes.

Les principes d’attention servent de repères, pas de promesse de vues. Le skill n’impose ni structure universelle, ni mots familiers obligatoires, ni longueur fixe. Le français de ton public et ta façon de parler restent prioritaires.

## Installer

### Avec un assistant capable d’installer des skills

Copie cette demande :

```text
Installe le skill capter-attention depuis ce dépôt :
https://github.com/dan-ai-lab/capter-attention
Le dossier du skill est capter-attention/.
Utilise-le pour mes scripts courts, hooks et légendes en français,
avec mon profil de voix si j’en ai un.
```

### Dans Claude Code

Copie le dossier [`capter-attention`](capter-attention/) dans `~/.claude/skills/` pour tous tes projets, ou dans `.claude/skills/` pour un seul projet. Le fichier final doit être `capter-attention/SKILL.md` dans ce répertoire.

[Documentation officielle des skills](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview).

### Dans Claude, avec un ZIP

Télécharge [`capter-attention.zip`](https://github.com/dan-ai-lab/capter-attention/releases/latest/download/capter-attention.zip) depuis la dernière version, puis importe-le dans la section des skills personnalisés de Claude, si elle est disponible sur ton compte.

Ce ZIP contient directement le dossier du skill. Il est différent du ZIP de l’ensemble du dépôt proposé par le bouton **Code** de GitHub.

[Guide officiel d’importation](https://support.claude.com/en/articles/12512180-use-skills-in-claude).

### Dans un autre assistant

Si ton assistant accepte les dossiers au format `SKILL.md`, demande-lui d’installer `capter-attention/`. Sinon, fournis-lui le [fichier d’instructions](capter-attention/SKILL.md) et, au besoin, les [exemples](capter-attention/references/exemples.md), puis demande-lui de les appliquer. Le chargement automatique dépend de l’outil ; ce dépôt ne fournit pas une extension de navigateur.

## L’utiliser

Parle normalement à ton assistant. Par exemple :

> Écris un Reel pour montrer comment je transforme une note vocale en brief client. Mon public découvre l’IA. Voici les étapes que je peux montrer à l’écran et un de mes scripts validés pour le ton.

> Adapte ce script fourni en français. Garde son hook, son ordre et ses exemples. Si un passage personnel ne correspond pas à ce que tu sais de moi, demande-moi avant de le remplacer.

> Cette phrase ne me ressemble pas. Corrige seulement ce passage et rends-moi le script complet.

> Prépare ce script pour mon prompteur : un fichier .txt, une ligne vide entre chaque phrase, aucune indication de jeu.

Pour un résultat personnel, donne-lui un exemple que tu as réellement validé. Pour une démonstration, indique ce qu’on verra à l’écran. Le skill ne peut pas deviner ton vécu ni vérifier une vidéo qu’il ne peut pas consulter.

## Contenu du dépôt

- [`capter-attention/SKILL.md`](capter-attention/SKILL.md) : les instructions du skill.
- [`capter-attention/references/exemples.md`](capter-attention/references/exemples.md) : des exemples de décisions éditoriales.
- [`evals/cas.md`](evals/cas.md) : des cas pour évaluer le comportement de ton assistant.

## Origine

Le projet [Content Principles de Rémy Gaskell](https://github.com/aiwithremy/content-principles) a inspiré l’idée de publier un skill consacré à l’écriture et à l’attention.

Ce dépôt propose des instructions et des exemples rédigés séparément, à partir du travail éditorial de Dan AI Lab en français. Il ne reproduit pas le texte de Rémy et n’est pas une traduction officielle ou un projet affilié.

## Licence

Le contenu original de ce dépôt est publié sous [licence MIT](LICENSE). Tu peux l’utiliser, le modifier et le partager en conservant la notice de licence.
