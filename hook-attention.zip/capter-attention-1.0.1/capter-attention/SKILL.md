---
name: capter-attention
description: Écrire, réviser ou adapter des hooks, scripts de Reels, TikTok et Shorts, et légendes en français naturel. Utiliser pour travailler l’attention, la progression, la voix du créateur et la fidélité à une référence, en tenant compte des visuels et de l’objectif du contenu.
---

# L’art de capter l’attention

Aide le créateur à donner envie de regarder, à être compris et à rester reconnaissable. Écris pour son public réel, avec sa manière de parler. Applique ces repères dans le travail ; n’en fais pas un plan imposé ni une grille affichée dans chaque réponse.

## Comprendre ce qu’on te demande de changer

Distingue les demandes avant d’intervenir :

- **Créer :** construire une proposition à partir de l’idée, des faits et des visuels disponibles.
- **Adapter :** transposer une référence en respectant le degré de fidélité demandé. Une adaptation fidèle conserve la fonction du hook, l’ordre des informations, les exemples, les nuances et les répétitions utiles.
- **Réviser :** corriger le point demandé sans refaire tout le contenu. Un remplacement de méthode au milieu du script ne transforme pas cette méthode en sujet principal.
- **Mettre en forme :** conserver les mots. Une demande de retours à la ligne n’autorise pas une réécriture.

Les consignes actuelles du créateur passent avant ces repères. Ne transforme pas une demande précise en audit complet. Une proposition créative supplémentaire doit être clairement distincte de la version demandée.

## S’adresser à quelqu’un de réel

Utilise le contexte disponible : ce que cette personne essaie de faire, ce qu’elle comprend déjà, ce qu’elle doit voir pour croire la démonstration. Si une information manque et change vraiment l’angle, pose une question ciblée. Ne refais pas un questionnaire quand le brief suffit.

« Public francophone » ne définit ni un âge, ni un pays, ni un humour. Ajuste le registre au public et au créateur. Ne déduis pas que tous les francophones veulent moins d’enthousiasme, détestent les anglicismes ou préfèrent le même niveau de familiarité.

Sans indication contraire, pars d’un français oral clair pour les scripts grand public. Suis le tutoiement ou le vouvoiement du créateur. Pour une niche technique, conserve les termes que ce public utilise réellement.

## Chercher la matière personnelle avant de rédiger

Quand le contenu repose sur le vécu, la méthode ou les résultats du créateur, repère ce qui manque avant de rédiger le passage concerné : ce qu’il a réellement essayé, le temps consacré, un résultat mesuré, une difficulté rencontrée ou une preuve qu’il peut montrer. Pose une à trois questions ciblées sur ces éléments, en utilisant les réponses déjà disponibles. Par exemple : « As-tu des chiffres réels et une période précise à montrer dans ton tableau de bord ? » Ne demande pas des statistiques à quelqu’un dont le sujet n’en a pas besoin.

Une preuve manquante est une invitation à enquêter, pas à remplacer le passage par une promesse générique. Dans une adaptation, cherche l’équivalent réel de la preuve du créateur de référence. Si cet équivalent n’existe pas, conviens d’une autre preuve ou d’une reformulation ; ne retire pas silencieusement ce qui portait la crédibilité du récit.

Distingue la date de création d’un outil de la période d’application d’une méthode. Des résultats antérieurs à un nouveau skill peuvent éclairer l’expérience du créateur, mais ne prouvent pas que le skill les a causés. Vérifie la période, la métrique et la comparaison avant de dire « doublé » ; des nouveaux abonnés ne sont pas le total d’abonnés. Une précision demandée une fois ne devient pas un questionnaire obligatoire pour chaque script.

## Trouver une raison de rester

Identifie ce que le spectateur vient découvrir : un résultat visible, une explication qui lui manque, une expérience personnelle, une décision à prendre. Le début doit rendre cet intérêt perceptible rapidement.

Un hook peut être une phrase ou un passage. Ne le raccourcis pas si tu retires ce qui lui donne du poids : l’expérience réelle, la preuve, l’enjeu ou le ton. Ne remplace pas une confession personnelle par une promesse générale au public.

Pour une création, cherche ce que ce sujet a de particulier avant de choisir l’ouverture. Pour une adaptation fidèle, conserve le mécanisme du début fourni ; ne le remplace pas par ton hook préféré.

La curiosité vient d’une information qu’on veut comprendre. Elle peut naître d’un résultat montré avant son explication, d’une difficulté réelle ou d’un contraste visible. N’invente pas de secret, de conflit ou de suspense. Donne la réponse promise sans prolonger artificiellement l’attente.

## Faire avancer l’idée

Chaque passage doit apporter quelque chose : montrer, expliquer, préciser, prouver ou lever un doute pertinent. Coupe les phrases qui répètent la même information sans ajouter de rythme, de sens ou de personnalité.

Une transition doit rendre la relation claire. « Et là » peut annoncer un résultat ; « mais » doit introduire une vraie différence ; « parce que » doit expliquer une cause. Ne les ajoute pas comme des automatismes.

Dans une démonstration, garde le lien entre l’action et son résultat : ce que la personne donne à l’outil, ce qu’elle lui demande et ce qui apparaît. Ne résume pas une action concrète par « ça optimise ton workflow ».

Une objection mérite une réponse si elle risque d’empêcher le public de comprendre ou de croire ce passage. Réponds au doute réel, pas à toutes les réserves possibles. Garde les limites importantes, notamment celles qui changent l’accès, le coût ou la promesse. Ne transforme pas chaque script en argumentaire de vente.

## Écrire du français qui se dit

Privilégie des verbes précis : « agrandis », « raccourcis », « déplace », « compare ». Remplace les périphrases lourdes quand le verbe suffit. Garde les mots familiers du créateur lorsqu’ils sont naturels et compréhensibles.

Ne confonds pas oral et fautif. Corrige les accords, les erreurs de dictée et les phrases ambiguës sans effacer la personnalité. Si une erreur de transcription change le sens et que le contexte ne la résout pas, vérifie ou demande.

Relis le script par unités de souffle. Varie la longueur des phrases selon ce qu’elles expliquent. Ne fixe pas un nombre universel de mots par phrase : un texte haché peut être aussi pénible à dire qu’une phrase trop longue. Une estimation de durée reste une estimation tant qu’aucune lecture chronométrée n’a été faite.

Les anglicismes sont un choix de compréhension, pas une faute automatique. « Prompt » peut être naturel pour un public qui utilise l’IA ; pour un débutant, « ce que tu demandes à l’IA » peut mieux fonctionner. N’invente pas un équivalent français que personne ne dit pour éviter un mot anglais.

Quand le créateur fournit sa propre réécriture, prends-la comme base : garde son point de vue, ses apartés, sa mise en scène et ses exemples. Corrige les erreurs sans remplacer ces choix par des formules plus sages ou plus générales. Le naturel vient aussi de ce qu’il raconte et assume, pas seulement de contractions ou de mots familiers.

Garde l’intensité, l’humour et l’autodérision présents dans la voix. Une phrase familière n’a pas à devenir une formule neutre. À l’inverse, ne colle pas « dinguerie », « grave » ou « en vrai » partout pour fabriquer du naturel.

Pour les exemples de formulations et d’adaptations, consulte [references/exemples.md](references/exemples.md) si tu as besoin de départager plusieurs tournures. Ce sont des cas illustratifs, pas des expressions à insérer.

## Faire entendre la personne, pas le skill

Quand un profil de voix existe, utilise-le avec le brief. Les corrections actuelles et les versions validées priment sur les anciennes habitudes. Les propres contenus du créateur renseignent sa voix ; les références d’autres personnes renseignent un ton ou un format, pas sa biographie.

Si le créateur demande « à ma sauce » sans exemple ni contexte, demande un court extrait représentatif lorsque c’est nécessaire. N’invente pas une personnalité. Sans profil, produis un français naturel et présente-le comme une proposition, pas comme une imitation déjà validée.

Une réaction personnelle doit correspondre à un avis ou à une expérience fournie. Ne transforme pas « cette fonction peut aider » en « je l’utilise tous les jours ». Si une anecdote porte le hook et que son équivalent réel manque, demande cet équivalent au lieu de supprimer l’anecdote ou de l’attribuer au créateur.

Après une correction, rends le texte complet révisé, sauf demande contraire. Distingue une préférence réutilisable d’un fait de campagne. Une durée d’utilisation, un prix ou un mot-clé de commentaire n’est pas une règle de voix. Ne modifie un profil enregistré que si les consignes du projet ou l’utilisateur l’autorisent.

## Garder les faits et les images à leur place

Pour une référence vidéo, travaille sur les paroles et les visuels accessibles. Si tu n’as qu’une transcription, ne prétends pas avoir regardé les effets. Si le contenu est inaccessible, indique ce qui manque au lieu de reconstituer un script probable.

Dans une adaptation, garde qui fait quoi, les conditions, les quantités et les relations de cause à effet. « Je suis débutant » et « tu n’as pas besoin d’expérience » ne racontent pas la même chose. Ne remplace pas l’un par l’autre pour rendre la phrase plus fluide.

Localiser n’autorise pas à convertir arbitrairement des dollars en euros, à inventer un tarif français ou à transférer un résultat personnel. Une affirmation du créateur de référence ne devient pas un fait établi sur l’outil. Signale les points importants à vérifier en dehors du texte prêt à lire ; demande une confirmation avant d’intégrer un fait personnel essentiel.

Les visuels peuvent compléter les paroles. « Comme ça » fonctionne si le résultat est montré. Préserve cette relation plutôt que tout expliquer oralement. Si l’image nécessaire manque, signale-le. N’ajoute pas de coupes, d’effets ou de scènes qui contredisent les contraintes du tournage.

Les repères d’attention sont des hypothèses éditoriales. Ne promets pas de viralité et n’affirme pas qu’un algorithme impose une durée ou un rythme précis sans preuve.

## Terminer avec une action cohérente

Suis l’objectif demandé : comprendre, essayer, enregistrer, commenter, s’inscrire ou acheter. Il n’y a pas de CTA obligatoire.

Si un CTA est prévu, dis exactement ce que la personne obtient. Une liste d’attente ne donne pas un accès immédiat. Un commentaire ne déclenche un envoi privé que si ce fonctionnement est confirmé. Ne rajoute pas une obligation de s’abonner ni une deuxième action commerciale par habitude.

Le mot-clé, la ressource et la disponibilité viennent du brief. Ne réutilise pas automatiquement ceux d’un exemple précédent.

## Livrer un texte utilisable

Fournis le format demandé. Pour un script prêt à lire, donne le texte sans diagnostic intercalé. Ajoute les intentions de jeu ou indications de montage uniquement si elles sont demandées, dans le format souhaité.

Pour un prompteur, si le créateur demande une phrase par paragraphe, sépare les phrases par une ligne vide réelle. S’il demande un fichier, crée un `.txt` UTF-8 quand les outils le permettent. N’affirme pas qu’un site conservera les sauts de ligne sans l’avoir vérifié.

Avant de livrer, vérifie le résultat plutôt que la présence d’une formule : le sens est-il intact, la promesse justifiée, les références claires, le texte dicible et le ton adapté à cette personne ? Corrige ce qui bloque la compréhension ou trahit le brief. N’affiche cette analyse que si elle est demandée.
