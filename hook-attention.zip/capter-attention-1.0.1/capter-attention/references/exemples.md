# Exemples de décisions éditoriales

Ces exemples sont fictifs. Ils illustrent des choix de formulation, pas des performances mesurées. Ne réutilise ni leurs faits ni leurs CTA dans un autre brief.

## Un verbe suffit

- Lourd : « Fais en sorte que le texte ait une taille plus grande. »
- Direct : « Agrandis le texte. »
- Vague : « Améliore le rendu de cette partie. »
- Visible, si c’est bien la demande : « Éclaircis le fond et garde le texte en noir. »

La précision décrit une intention connue. Elle ne donne pas le droit d’inventer un effet à la place du créateur.

## Préserver la personne qui parle

Source fournie : « I’m terrible at drawing, and I made this poster myself. »

Adaptation fidèle : « Je suis nul en dessin, et cette affiche, je l’ai faite moi-même. »

« Pas besoin de savoir dessiner pour faire une affiche » transforme une expérience personnelle en promesse générale. Si le texte doit devenir celui d’un autre créateur, vérifier que l’expérience est vraie pour lui avant d’écrire à la première personne.

## Garder une vraie explication

Source fournie : « Here’s how I turn a voice note into a client brief. »

Français naturel : « Voilà comment je transforme une note vocale en brief client. »

« Et ça, tu peux le faire avec l’IA » supprime la transformation annoncée et change le sujet de « je » à « tu ».

## Remplacer une étape sans déplacer le sujet

Demande : « Garde la présentation de mon processus de création. Remplace uniquement le passage sur les fiches papier par mon tableau numérique. »

Conserver l’ouverture et les autres étapes. Décrire le tableau au moment où les fiches intervenaient, avec les fonctions confirmées par le créateur. Ne pas réécrire le hook autour du tableau numérique.

## Une référence visible n’est pas une phrase vide

Avec trois variantes montrées à l’écran : « Tu peux garder ce style… passer à celui-là… ou choisir celui-ci. »

Sans les visuels : demander les variantes ou les décrire à partir des informations disponibles. Ne pas inventer leur apparence.

## Le registre dépend du brief

Pour une démonstration familière : « Attends, regarde ce qu’il vient de faire. »

Pour une présentation professionnelle : « Voici le résultat obtenu avec le même document. »

Aucune version n’est universellement meilleure. Le choix dépend de la personne, du public et de la scène. Ne pas confondre un français naturel avec un registre obligatoirement familier.

## Un CTA honnête

Brief : le produit n’est pas disponible ; le commentaire « ATELIER » permet de recevoir le lien d’inscription à la liste d’attente.

Proposition : « Commente “ATELIER” et je t’envoie le lien pour rejoindre la liste d’attente. »

« Commente et reçois le produit » promet autre chose. « Je t’ajoute à la liste » est également inexact si une inscription reste nécessaire.

## Un fait inconnu reste inconnu

Brief : le créateur veut dire qu’il gagne du temps, mais n’a pas mesuré le gain.

Garder « ça m’évite de recopier chaque ligne » si cette action est confirmée. Ne pas écrire « je gagne deux heures par jour » pour rendre le hook plus frappant.

## Demander une preuve au lieu de l’effacer

Une référence présente une méthode, puis montre son résultat chiffré. Le créateur souhaite l’adapter, mais n’a pas fourni ses propres chiffres.

Question utile : « Quel résultat réel peux-tu montrer, sur quelle période ? As-tu une comparaison avec la période précédente ? »

Remplacer directement cette preuve par « le but, c’est de créer du meilleur contenu » fait perdre la crédibilité et le vécu du passage. Demander la matière manquante permet de conserver sa fonction sans reprendre les chiffres de quelqu’un d’autre.

## Une méthode ancienne, un outil récent

Le créateur explique qu’il applique sa méthode depuis plusieurs mois et vient de la réunir dans un skill. Ses chiffres couvrent le mois précédent.

Formulation possible : « J’applique déjà ces principes dans mes vidéos. Sur le dernier mois, voilà mes résultats. Aujourd’hui, je les ai réunis dans ce skill. »

Ne pas écrire « ce skill a généré ces résultats ». Même l’usage confirmé d’une méthode ne prouve pas qu’elle explique seule la croissance.
